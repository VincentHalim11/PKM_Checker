import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'services/validator_service.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PKM Checker Test',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.deepPurple,
        ),
        useMaterial3: true,
      ),
      home: const ValidatorTestPage(),
    );
  }
}

class ValidatorTestPage extends StatefulWidget {
  const ValidatorTestPage({super.key});

  @override
  State<ValidatorTestPage> createState() => _ValidatorTestPageState();
}

  // ==========================================================
  // UI
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PKM Checker Test'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            // Judul
            const Text(
              'Flutter → Python → JSON',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 30),

            // ==================================================
            // FILE PDF
            // ==================================================

            const Text(
              'File PDF',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            // Tampilkan file yang dipilih
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text(
                _selectedPdfPath ?? 'Belum ada file dipilih',
                textAlign: TextAlign.center,
              ),
            ),

            const SizedBox(height: 15),

            // Tombol pilih PDF
            ElevatedButton.icon(
              onPressed: _isLoading ? null : _pickPdf,
              icon: const Icon(Icons.folder_open),
              label: const Text('Pilih PDF'),
            ),

            const SizedBox(height: 30),

            const SizedBox(height: 25),

            const Text(
              'Skema PKM',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            DropdownButton<String>(
              value: _selectedScheme,
              items: const [
                DropdownMenuItem(
                  value: 'GFT',
                  child: Text('PKM-GFT'),
                ),
                DropdownMenuItem(
                  value: 'AI',
                  child: Text('PKM-AI'),
                ),
                DropdownMenuItem(
                  value: 'K',
                  child: Text('PKM-K'),
                ),
                DropdownMenuItem(
                  value: 'KC',
                  child: Text('PKM-KC'),
                ),
                DropdownMenuItem(
                  value: 'KI',
                  child: Text('PKM-KI'),
                ),
                DropdownMenuItem(
                  value: 'PI',
                  child: Text('PKM-PI'),
                ),
                DropdownMenuItem(
                  value: 'PM',
                  child: Text('PKM-PM'),
                ),
                DropdownMenuItem(
                  value: 'RE',
                  child: Text('PKM-RE'),
                ),
                DropdownMenuItem(
                  value: 'RSH',
                  child: Text('PKM-RSH'),
                ),
                DropdownMenuItem(
                  value: 'VGK',
                  child: Text('PKM-VGK'),
                ),
              ],
              onChanged: _isLoading
                  ? null
                  : (value) {
                      if (value != null) {
                        setState(() {
                          _selectedScheme = value;
                          _status = 'Belum diuji';
                          _error = null;
                        });
                      }
                    },
            ),

            // ==================================================
            // BUTTON VALIDATOR
            // ==================================================

            ElevatedButton(
              onPressed: _isLoading ? null : _runValidator,
              child: Text(
                _isLoading
                    ? 'Memeriksa...'
                    : 'Jalankan Validator',
              ),
            ),

            const SizedBox(height: 30),

            // ==================================================
            // STATUS
            // ==================================================

            Text(
              'Status: $_status',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

            // ==================================================
            // ERROR
            // ==================================================

            if (_error != null) ...[
              const SizedBox(height: 20),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                  _error!,
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}