import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/validator_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _selectedPdfPath;

  String _selectedScheme = 'K';

  String _status = 'Belum diuji';
  bool _isLoading = false;
  String? _error;

  // ==========================================================
  // PILIH PDF
  // ==========================================================

  Future<void> _pickPdf() async {
  final file = await FilePicker.pickFile(
    type: FileType.custom,
    allowedExtensions: ['pdf'],
  );

  if (file != null && file.path != null) {
    setState(() {
      _selectedPdfPath = file.path;
      _status = 'Belum diuji';
      _error = null;
    });
  }
}

  // ==========================================================
  // JALANKAN VALIDATOR
  // ==========================================================

  Future<void> _runValidator() async {
    // Jangan jalankan validator kalau belum memilih PDF
    if (_selectedPdfPath == null) {
      setState(() {
        _error = 'Silakan pilih file PDF terlebih dahulu.';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _status = 'Sedang memeriksa...';
      _error = null;
    });

    try {
      final result = await ValidatorService.validate(
        pdfPath: _selectedPdfPath!,
        scheme: _selectedScheme,
      );

      setState(() {
        _status = result['status']?.toString() ?? 'UNKNOWN';
      });
    } catch (e) {
      setState(() {
        _status = 'ERROR';
        _error = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }

  // lanjutkan kode _pickPdf()
  // lanjutkan kode _runValidator()
  // lanjutkan kode build()
}